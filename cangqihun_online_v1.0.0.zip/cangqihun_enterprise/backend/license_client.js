// ===== 授权客户端 =====
const fs = require('fs');
const path = require('path');

const LICENSE_SERVER = 'http://127.0.0.1:18900';
const BASE_DIR = 'C:\\cangqihun_enterprise\\enterprises\\CANGQI_001';

let licenseCache = null;

function getLicenseCachePath() {
    return path.join(BASE_DIR, 'license_cache.json');
}

function loadLicenseCache() {
    try {
        const cachePath = getLicenseCachePath();
        if (fs.existsSync(cachePath)) {
            return JSON.parse(fs.readFileSync(cachePath, 'utf-8'));
        }
    } catch (e) {}
    return null;
}

function saveLicenseCache(data) {
    const cachePath = getLicenseCachePath();
    const dir = path.dirname(cachePath);
    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
    }
    fs.writeFileSync(cachePath, JSON.stringify(data, null, 2), 'utf-8');
}

async function verifyLicense(userId, keyHash) {
    try {
        const res = await fetch(LICENSE_SERVER + '/api/license/verify', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ userId, keyHash }),
            signal: AbortSignal.timeout(5000)
        });
        const data = await res.json();
        if (data.success) {
            licenseCache = data.data;
            saveLicenseCache(licenseCache);
            return data.data;
        }
        return null;
    } catch (e) {
        console.log('⚠️ 授权服务器不可用，使用本地缓存');
        const cached = loadLicenseCache();
        if (cached) {
            return cached;
        }
        return null;
    }
}

async function registerLicense(userId, keyHash) {
    const res = await fetch(LICENSE_SERVER + '/api/license/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, keyHash }),
        signal: AbortSignal.timeout(5000)
    });
    const data = await res.json();
    if (data.success) {
        licenseCache = data.data;
        saveLicenseCache(licenseCache);
        return data.data;
    }
    return null;
}

async function unlockLicense(userId, keyHash, unlockCode) {
    const res = await fetch(LICENSE_SERVER + '/api/license/unlock', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, keyHash, unlockCode }),
        signal: AbortSignal.timeout(5000)
    });
    const data = await res.json();
    if (data.success) {
        licenseCache = data.data;
        saveLicenseCache(licenseCache);
        return data.data;
    }
    return null;
}

function isLicenseValid(licenseData) {
    if (!licenseData) return false;
    if (licenseData.is_unlocked) return true;
    if (licenseData.status === 'expired') return false;
    if (licenseData.remaining_days <= 0 && licenseData.remaining_uses <= 0) return false;
    return true;
}

module.exports = {
    loadLicenseCache,
    saveLicenseCache,
    verifyLicense,
    registerLicense,
    unlockLicense,
    isLicenseValid
};