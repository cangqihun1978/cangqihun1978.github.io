const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const app = express();
const PORT = 18889;

app.use(cors());
app.use(express.json({ limit: '50mb' }));
// ===== 路由保护：禁止直接访问敏感文件 =====
app.use((req, res, next) => {
    const sensitiveExts = ['.json', '.env', '.log', '.key', '.pem'];
    const ext = req.path.split('.').pop();
    if (sensitiveExts.includes('.' + ext)) {
        return res.status(403).send('Access Denied');
    }
    next();
});

// ===== 确保必要目录存在 =====
function ensureDir(dir) {
    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
    }
}

// ===== 路径常量 =====
const ENTERPRISES_BASE = path.join(__dirname, '..', 'enterprises', 'CANGQI_001');
const AVATARS_BASE = path.join(ENTERPRISES_BASE, 'avatars');
const REPORTS_DIR = path.join(ENTERPRISES_BASE, 'reports');
const AUDIT_DIR = path.join(ENTERPRISES_BASE, 'audit');
const LEARNING_BASE = path.join(ENTERPRISES_BASE, 'learning');

ensureDir(REPORTS_DIR);
ensureDir(AUDIT_DIR);
ensureDir(LEARNING_BASE);

// ===== 当前激活的分身 =====
let currentAvatar = '傅清源';

function getAvatarBase(avatarName) {
    return path.join(AVATARS_BASE, avatarName);
}

function getAvatarLearningDir(avatarName) {
    return path.join(getAvatarBase(avatarName), 'soul', 'learning');
}

function getAvatarRulesDir(avatarName) {
    return path.join(getAvatarBase(avatarName), 'soul', 'rules');
}

function getAvatarFieldsDir(avatarName) {
    return path.join(getAvatarBase(avatarName), 'soul', 'fields');
}

function getAvatarTemplatesDir(avatarName) {
    return path.join(getAvatarBase(avatarName), 'soul', 'templates');
}

// ===== 授权客户端集成 =====
const licenseClient = require('./license_client');

// ===== 授权状态缓存 =====
let licenseData = null;
let userId = null;
let keyHash = null;
// ===== 从本地加载或创建用户ID =====
function getUserId() {
    const idPath = path.join(ENTERPRISES_BASE, 'user_id.json');
    try {
        if (fs.existsSync(idPath)) {
            const data = JSON.parse(fs.readFileSync(idPath, 'utf-8'));
            return data.userId;
        }
    } catch (e) { }
    return null;
}

function saveUserId(id) {
    const idPath = path.join(ENTERPRISES_BASE, 'user_id.json');
    ensureDir(path.dirname(idPath));
    fs.writeFileSync(idPath, JSON.stringify({ userId: id }, null, 2), 'utf-8');
}

// ===== 授权状态接口 =====
app.get('/api/license/status', async (req, res) => {
    const cached = licenseClient.loadLicenseCache();
    if (cached) {
        return res.json({ success: true, data: cached });
    }
    res.json({ success: false, data: null, status: 'not_registered' });
});

// ===== 注册接口 =====
app.post('/api/license/register', async (req, res) => {
    const { userId: inputUserId, keyHash: inputKeyHash } = req.body;
    if (!inputUserId || !inputKeyHash) {
        return res.status(400).json({ success: false, error: '缺少用户ID或密钥哈希' });
    }

    userId = inputUserId;
    keyHash = inputKeyHash;
    saveUserId(userId);

    const data = await licenseClient.registerLicense(userId, keyHash);
    if (data) {
        licenseData = data;
        res.json({ success: true, data });
    } else {
        res.status(500).json({ success: false, error: '注册失败' });
    }
});

// ===== 解锁接口 =====
app.post('/api/license/unlock', async (req, res) => {
    const { unlockCode } = req.body;
    if (!unlockCode) {
        return res.status(400).json({ success: false, error: '缺少解锁码' });
    }

    if (!userId || !keyHash) {
        return res.status(400).json({ success: false, error: '请先注册' });
    }

    const data = await licenseClient.unlockLicense(userId, keyHash, unlockCode);
    if (data) {
        licenseData = data;
        res.json({ success: true, data });
    } else {
        res.status(400).json({ success: false, error: '解锁码无效' });
    }
});

// ===== 智谱 API 配置 =====
const ZHIPU_API_KEY = '58f29af72485471295d1aadd6f484475.qIdE2ZpbwyV5gOQb';
const ZHIPU_ENDPOINT = 'https://open.bigmodel.cn/api/paas/v4/chat/completions';

// ===== 加载学习容器 =====
function loadLearningMemory(avatarName) {
    const learningDir = getAvatarLearningDir(avatarName);
    const memoryPath = path.join(learningDir, 'learning_memory.json');
    try {
        if (fs.existsSync(memoryPath)) {
            return JSON.parse(fs.readFileSync(memoryPath, 'utf-8'));
        }
    } catch (e) { }
    return {
        version: '1.0.0',
        last_updated: new Date().toISOString(),
        status: 'active',
        affirmation_pool: [],
        negation_pool: [],
        sessions: [],
        stats: { total_sessions: 0, affirmation_count: 0, negation_count: 0 },
        feedback_log: []
    };
}

function saveLearningMemory(avatarName, memory) {
    const learningDir = getAvatarLearningDir(avatarName);
    ensureDir(learningDir);
    const memoryPath = path.join(learningDir, 'learning_memory.json');
    memory.last_updated = new Date().toISOString();
    fs.writeFileSync(memoryPath, JSON.stringify(memory, null, 2), 'utf-8');
}

function loadRules(industry, avatarName) {
    const rulesDir = getAvatarRulesDir(avatarName);
    const ruleFiles = {
        'bank': 'contract_bank.json',
        'school': 'contract_school.json',
        'hospital': 'contract_hospital.json',
        'gov': 'contract_gov.json',
        'law': 'contract_law.json'
    };
    const fileName = ruleFiles[industry];
    if (!fileName) return null;
    const filePath = path.join(rulesDir, fileName);



    console.log('📂 规则库路径:', filePath);
    try {
        if (fs.existsSync(filePath)) {
            const content = fs.readFileSync(filePath, 'utf-8');
            const parsed = JSON.parse(content);
            let rulesArray = [];
            if (parsed.rules && Array.isArray(parsed.rules)) {
                rulesArray = parsed.rules;
            } else if (parsed.dimensions && Array.isArray(parsed.dimensions)) {
                for (const dim of parsed.dimensions) {
                    if (dim.rules && Array.isArray(dim.rules)) {
                        rulesArray = rulesArray.concat(dim.rules);
                    }
                }
            }
            // 规范化：确保每个规则都有 keywords 数组
            for (const rule of rulesArray) {
                if (!rule.keywords) {
                    rule.keywords = [];
                }
                if (!Array.isArray(rule.keywords)) {
                    if (typeof rule.keywords === 'string') {
                        rule.keywords = rule.keywords.split(/[,，\s]+/).filter(k => k.trim());
                    } else {
                        rule.keywords = [];
                    }
                }
            }
            console.log('📋 解析后的规则数量:', rulesArray.length);
            return { rules: rulesArray };
        }
    } catch (e) {
        console.error('加载规则库失败:', e.message);
    }
    return null;
}
// ===== 加载肯定池/否定池（按分身隔离） =====
function loadAffirmationPool(avatarName, industry) {
    const learningDir = getAvatarLearningDir(avatarName);
    const poolPath = path.join(learningDir, 'affirmation_pool_bank.json');
    try {
        if (fs.existsSync(poolPath)) {
            const data = JSON.parse(fs.readFileSync(poolPath, 'utf-8'));
            return data.industries?.[industry]?.affirmation_pool || [];
        }
    } catch (e) { }
    return [];
}

function loadNegationPool(avatarName, industry) {
    const learningDir = getAvatarLearningDir(avatarName);
    const poolPath = path.join(learningDir, 'negation_pool_bank.json');
    try {
        if (fs.existsSync(poolPath)) {
            const data = JSON.parse(fs.readFileSync(poolPath, 'utf-8'));
            return data.industries?.[industry]?.negation_pool || [];
        }
    } catch (e) { }
    return [];
}

function saveAffirmationPool(avatarName, industry, pool) {
    const learningDir = getAvatarLearningDir(avatarName);
    const poolPath = path.join(learningDir, 'affirmation_pool_bank.json');
    let data = { industries: {} };
    try {
        if (fs.existsSync(poolPath)) {
            data = JSON.parse(fs.readFileSync(poolPath, 'utf-8'));
        }
    } catch (e) { }
    if (!data.industries) data.industries = {};
    if (!data.industries[industry]) data.industries[industry] = { name: industry, affirmation_pool: [] };
    data.industries[industry].affirmation_pool = pool;
    data.industries[industry].count = pool.length;
    data.industries[industry].last_updated = new Date().toISOString();
    fs.writeFileSync(poolPath, JSON.stringify(data, null, 2), 'utf-8');
}

function saveNegationPool(avatarName, industry, pool) {
    const learningDir = getAvatarLearningDir(avatarName);
    const poolPath = path.join(learningDir, 'negation_pool_bank.json');
    let data = { industries: {} };
    try {
        if (fs.existsSync(poolPath)) {
            data = JSON.parse(fs.readFileSync(poolPath, 'utf-8'));
        }
    } catch (e) { }
    if (!data.industries) data.industries = {};
    if (!data.industries[industry]) data.industries[industry] = { name: industry, negation_pool: [] };
    data.industries[industry].negation_pool = pool;
    data.industries[industry].count = pool.length;
    data.industries[industry].last_updated = new Date().toISOString();
    fs.writeFileSync(poolPath, JSON.stringify(data, null, 2), 'utf-8');
}

// ===== 记录反馈 =====
function recordFeedback(avatarName, industry, feedback) {
    const learningDir = getAvatarLearningDir(avatarName);
    const feedbackPath = path.join(learningDir, 'feedback_log.json');
    let data = { version: '1.0.0', total_feedback: 0, affirmation_count: 0, negation_count: 0, records: [] };
    try {
        if (fs.existsSync(feedbackPath)) {
            data = JSON.parse(fs.readFileSync(feedbackPath, 'utf-8'));
        }
    } catch (e) { }
    data.records.push(feedback);
    data.total_feedback += 1;
    if (feedback.user_feedback === '是') {
        data.affirmation_count += 1;
    } else if (feedback.user_feedback === '不是') {
        data.negation_count += 1;
    }
    fs.writeFileSync(feedbackPath, JSON.stringify(data, null, 2), 'utf-8');
}
// ============================================================
//  语义关联层辅助函数
// ============================================================

/**
 * 检查合同中“优先权”相关条款是否存在逻辑矛盾
 * @param {string} text - 合同全文
 * @returns {Array} 矛盾列表
 */
function checkPriorityConsistency(text) {
    const issues = [];

    // 步骤1：提取所有包含“优先”的条款
    const lines = text.split('\n');
    const priorityClauses = [];
    let currentLineIndex = 0;
    for (const line of lines) {
        currentLineIndex++;
        if (line.includes('优先')) {
            priorityClauses.push({
                lineIndex: currentLineIndex,
                text: line.trim()
            });
        }
    }

    // 步骤2：如果没有两个以上的优先条款，跳过
    if (priorityClauses.length < 2) {
        return issues;
    }

    // 步骤3：检查是否存在矛盾
    // 场景1：A组优先于B组 vs B组优先于A组（或现金流优先B组）
    const hasAPriority = priorityClauses.some(c => c.text.includes('A组') && c.text.includes('优先'));
    const hasBPriority = priorityClauses.some(c => c.text.includes('B组') && c.text.includes('优先'));
    const hasCashflowPriorityB = priorityClauses.some(c => c.text.includes('现金流') && c.text.includes('优先') && c.text.includes('B组'));

    // 关键矛盾：A组优先于B组（第1.2条）但同时现金流优先B组（第3.2条）
    if (hasAPriority && hasCashflowPriorityB) {
        issues.push({
            id: 'SEM_001',
            name: '还款/分配优先权不一致',
            why: '合同同时约定"A组优先于B组"和"现金流优先用于B组偿还"，在资金分配维度上存在逻辑矛盾。两组优先权指向相反的结果。',
            consequence: '合同内部存在逻辑矛盾。当A组贷款人和B组贷款人同时主张优先受偿时，将无法确定谁是真正优先的债权人，引发争议。法院可能依据《民法典》第142条合同解释规则，对两条冲突条款进行整体解释，但不确定性极大。',
            suggestion: '建议将第3.2条修改为："上述收益权定向支持所产生的现金流，应优先用于A组贷款本息的偿付。A组贷款本息全部清偿后，剩余部分再用于B组贷款本息的偿付。"统一合同内的优先逻辑。'
        });
    }

    // 场景2：A组优先于B组 vs 现金流优先B组 的变体
    const hasPriorityA = priorityClauses.some(c => c.text.includes('A组') && c.text.includes('优先于'));
    const hasPriorityB = priorityClauses.some(c => c.text.includes('B组') && c.text.includes('优先于'));
    if (hasPriorityA && hasPriorityB) {
        issues.push({
            id: 'SEM_001b',
            name: '优先权相互冲突',
            why: '合同同时存在"A组优先于某对象"和"B组优先于某对象"两个不同方向的优先权条款，但未明确各自适用的维度。在资金分配维度上，两组优先权指向相反的结果。',
            consequence: '合同内部存在逻辑矛盾。当两个优先权条款同时指向资金分配维度时，将无法确定谁是真正优先的债权人，引发争议。法院可能依据《民法典》第142条合同解释规则进行整体解释，但存在重大不确定性。',
            suggestion: '建议在合同中增加明确说明："A组优先权适用于还款顺序，B组优先权适用于特定现金流分配，二者适用于不同场景。在涉及资金分配时，适用还款顺序优先规则。"'
        });
    }

    return issues;
}

/**
 * 检查银团贷款中代理行治理结构是否存在缺陷
 * @param {string} text - 合同全文
 * @returns {Array} 治理缺陷列表
 */
function checkAgencyGovernance(text) {
    const issues = [];

    // 步骤1：检查是否为银团贷款（含分组）
    const hasSyndicate = text.includes('银团') || text.includes('牵头行') || text.includes('代理行');
    const hasGroupA = text.includes('A组') || text.includes('A组贷款');
    const hasGroupB = text.includes('B组') || text.includes('B组贷款');

    if (!hasSyndicate || !hasGroupA || !hasGroupB) {
        return issues;
    }

    // 步骤2：检查代理行是否被授权代表全体
    const hasAgency = text.includes('代理行') && (text.includes('代表全体') || text.includes('行使本合同项下全部权利'));

    // 步骤3：检查分组之间是否存在权利不对等
    // A组有提前还款权 vs B组无
    const hasAPrepaymentRight = text.includes('A组') && text.includes('提前还款') && text.includes('有权');
    const hasBPrepaymentRight = text.includes('B组') && text.includes('提前还款') && text.includes('有权');

    if (hasAgency && hasAPrepaymentRight && !hasBPrepaymentRight) {
        issues.push({
            id: 'SEM_002',
            name: '代理行治理结构缺陷',
            why: '合同约定代理行代表全体贷款人行使权利，但A组贷款人享有提前还款权而B组贷款人无此权利。分组间存在权利不对等。代理行未经B组单独授权即可代表B组宣布提前到期，可能损害B组利益。',
            consequence: 'B组贷款人的利益在代理行行使权利时可能被忽略；代理行的决策可能损害B组利益；B组贷款人难以追责代理行因授权范围模糊而难以证明代理行违反忠实义务。',
            suggestion: '建议将第6.2条修改为："丙方有权代表全体贷款人行使本合同项下的权利，包括但不限于宣布贷款提前到期、要求借款人提前还款、行使担保权利、参与借款人破产程序等。但丙方行使上述权利中的任一重大事项前，应分别取得A组贷款人和B组贷款人的单独书面授权。"'
        });
    }

    // 场景2：代理行责任限额过低的治理缺陷（代理行重大过失责任与受托职责不匹配）
    const hasAgencyLiability = text.includes('代理行') && text.includes('赔偿') && text.includes('万元');
    if (hasAgencyLiability) {
        // 提取代理行责任限额
        const match = text.match(/代理行[^，。]*赔偿[^，。]*(\d+)\s*万元/);
        if (match) {
            const limit = parseInt(match[1]);
            if (limit < 100) { // 限额低于100万元认定为过低
                issues.push({
                    id: 'SEM_002b',
                    name: '代理行责任限额过低',
                    why: '合同约定代理行因过失或疏忽造成损失的赔偿限额仅为' + limit + '万元。代理行管理的贷款总额超过数亿元，责任与收益严重不对等。',
                    consequence: '代理行可能因责任限额过低而怠于履行监督义务，导致贷款人损失。法院可能依据《民法典》第497条认定该条款因"不合理地免除或减轻其责任、加重对方责任、限制对方主要权利"而无效。',
                    suggestion: '建议修改代理行责任条款：' +
                        '方案一（推荐）：删除责任限额条款，代理行应就其重大过失或故意行为导致的全部损失承担赔偿责任。' +
                        '方案二（折中）：将责任限额提高至代理费总额的3-5倍，或设定一个与贷款总额挂钩的合理比例。'
                });
            }
        }
    }

    return issues;
}

/**
 * 检查合同中是否存在“放弃格式条款权利”等无效声明
 * @param {string} text - 合同全文
 * @returns {Array} 无效声明列表
 */
function checkInvalidWaivers(text) {
    const issues = [];

    // 检查是否包含“放弃格式条款权利”类表述
    if (text.includes('放弃') && text.includes('格式条款')) {
        issues.push({
            id: 'SEM_003',
            name: '放弃法定权利的无效声明',
            why: '合同约定"放弃就格式条款主张任何权利"，属于以合同约定方式排除《民法典》第496-498条格式条款强制性规定的适用。预先放弃法定权利在法律上无效。',
            consequence: '该放弃声明被法院认定无效；但整份合同可能因监管违规而面临效力挑战；金融机构面临监管处罚和声誉损失。',
            suggestion: '建议删除该放弃声明。如需保留合规确认，修改为："各方确认，本合同条款已根据现行有效法律法规进行合规性评估。各方保留法律赋予的全部权利，本条款不构成任何一方对法定权利的预先放弃。"'
        });
    }

    return issues;
}
// ===== 审查引擎 =====
function reviewContract(text, rules) {
    if (!rules || !rules.rules) {
        return { hits: [], score: 0, level: '未知' };
    }
    const hits = [];
    let score = 100;
    function reviewContract(text, rules) {
        if (!rules || !rules.rules) {
            return { hits: [], score: 0, level: '未知' };
        }
        const hits = [];
        let score = 100;

        // ============================================================
        //  语义关联层执行（在规则匹配之前扫描整个合同）
        // ============================================================

        // 1. 检查优先权一致性
        const priorityIssues = checkPriorityConsistency(text);
        for (const issue of priorityIssues) {
            hits.push({
                id: issue.id || 'SEM_001',
                name: issue.name || '跨条款逻辑矛盾',
                why: issue.why || '合同内部存在逻辑不一致',
                consequence: issue.consequence || '可能导致争议或条款无效',
                suggestion: issue.suggestion || '建议统一相关条款的表述'
            });
            score = score - 10;
        }

        // 2. 检查代理行治理结构
        const agencyIssues = checkAgencyGovernance(text);
        for (const issue of agencyIssues) {
            hits.push({
                id: issue.id || 'SEM_002',
                name: issue.name || '代理行治理结构缺陷',
                why: issue.why || '代理行授权范围存在治理缺陷',
                consequence: issue.consequence || '可能损害部分贷款人利益',
                suggestion: issue.suggestion || '建议明确代理行行使重大权利的分别授权机制'
            });
            score = score - 10;
        }

        // 3. 检查无效放弃声明
        const waiverIssues = checkInvalidWaivers(text);
        for (const issue of waiverIssues) {
            hits.push({
                id: issue.id || 'SEM_003',
                name: issue.name || '放弃法定权利的无效声明',
                why: issue.why || '以合同约定方式排除法定权利，该约定无效',
                consequence: issue.consequence || '该声明被认定无效，但不影响整份合同效力',
                suggestion: issue.suggestion || '删除或修改为合规确认条款'
            });
            score = score - 10;
        }

        // ============================================================
        //  原有规则引擎（关键词匹配）
        // ============================================================

        for (const rule of rules.rules) {
            let matched = false;
            for (const keyword of rule.keywords) {
                if (text.includes(keyword)) {
                    matched = true;
                    break;
                }
            }
            if (matched) {
                hits.push({
                    id: rule.id,
                    name: rule.name,
                    why: rule.why || '未提供依据',
                    consequence: rule.consequence || '未提供后果说明',
                    suggestion: rule.suggestion || '未提供修改建议'
                });
                score = score - 5;
            }
        }

        // ============================================================
        //  评分与报告生成
        // ============================================================

        score = Math.max(0, score);
        const level = score >= 90 ? '低风险' : score >= 70 ? '中等风险' : '高风险';
        return { hits, score, level };
    }










    for (const rule of rules.rules) {
        let matched = false;
        for (const keyword of rule.keywords) {
            if (text.includes(keyword)) {
                matched = true;
                break;
            }
        }
        if (matched) {
            hits.push({
                id: rule.id,
                name: rule.name,
                why: rule.why || '未提供依据',
                consequence: rule.consequence || '未提供后果说明',
                suggestion: rule.suggestion || '未提供修改建议'
            });
            score = score - 5;
        }
    }
    const level = score >= 90 ? '低风险' : score >= 70 ? '中等风险' : '高风险';
    return { hits, score, level };
}

// ===== 健康检查 =====
app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', message: '藏器魂 · 主权审查体验版' });
});

// ===== 获取资产库总览 =====
app.get('/api/assets/dashboard', (req, res) => {
    const dashboardPath = path.join(ENTERPRISES_BASE, 'assets', 'dashboard.json');
    try {
        if (fs.existsSync(dashboardPath)) {
            const content = fs.readFileSync(dashboardPath, 'utf-8');
            res.json({ success: true, data: JSON.parse(content) });
        } else {
            res.json({ success: false, error: '资产库总览不存在' });
        }
    } catch (e) {
        res.status(500).json({ success: false, error: e.message });
    }
});

// ===== 获取行业规则库（按分身隔离） =====
app.get('/api/assets/rules/:industry', (req, res) => {
    const { industry } = req.params;
    const avatar = req.query.avatar || currentAvatar;
    const rules = loadRules(industry, avatar);
    if (rules) {
        res.json({ success: true, data: rules });
    } else {
        res.json({ success: false, error: '规则库不存在' });
    }
});

// ===== 获取当前分身 =====
app.get('/api/avatar/current', (req, res) => {
    res.json({ success: true, avatar: currentAvatar });
});

// ===== 切换分身 =====
app.post('/api/avatar/switch', (req, res) => {
    const { avatar } = req.body;
    if (!avatar) {
        return res.status(400).json({ success: false, error: '缺少分身名称' });
    }
    const avatarPath = getAvatarBase(avatar);
    if (!fs.existsSync(avatarPath)) {
        return res.status(404).json({ success: false, error: '分身不存在' });
    }
    currentAvatar = avatar;
    res.json({ success: true, avatar: currentAvatar });
});

// ===== 获取分身列表 =====
app.get('/api/avatars/list', (req, res) => {
    try {
        const avatars = [];
        if (fs.existsSync(AVATARS_BASE)) {
            const items = fs.readdirSync(AVATARS_BASE, { withFileTypes: true });
            for (const item of items) {
                if (item.isDirectory()) {
                    const identityPath = path.join(AVATARS_BASE, item.name, 'identity.json');
                    let identity = null;
                    try {
                        if (fs.existsSync(identityPath)) {
                            identity = JSON.parse(fs.readFileSync(identityPath, 'utf-8'));
                        }
                    } catch (e) { }
                    avatars.push({
                        name: item.name,
                        identity: identity || { name: item.name, description: '数字分身' }
                    });
                }
            }
        }
        // 默认至少有一个
        if (avatars.length === 0) {
            avatars.push({ name: '傅王侯', identity: { name: '傅王侯', description: '通用分身' } });
        }
        res.json({ success: true, avatars });
    } catch (e) {
        res.status(500).json({ success: false, error: e.message });
    }
});
// ===== 语义关联层 =====
function semanticAnalyzer(text, hits) {
    const conflicts = [];
    const context = {};

    // 提取所有包含“优先”关键词的条款位置
    const priorityClauses = extractClausesByKeywords(text, ['优先', '优先于', '优先受偿', '先于']);
    if (priorityClauses.length > 1) {
        // 检测多个“优先”条款之间的冲突
        const prioritySubjects = priorityClauses.map(c => extractPrioritySubject(c));
        const priorityObjects = priorityClauses.map(c => extractPriorityObject(c));
        // 如果主体或对象不一致，标记冲突
        if (new Set(prioritySubjects).size > 1 || new Set(priorityObjects).size > 1) {
            conflicts.push({
                type: 'priority_conflict',
                clauses: priorityClauses,
                message: '检测到多处还款顺序约定不一致，请确认条款之间的优先权分配是否存在冲突。'
            });
        }
    }

    // 提取所有包含“担保”“抵押”“质押”关键词的条款位置
    const guaranteeClauses = extractClausesByKeywords(text, ['担保', '抵押', '质押', '保证']);
    if (guaranteeClauses.length > 1) {
        // 检测担保范围冲突
        const guaranteeRanges = guaranteeClauses.map(c => extractGuaranteeRange(c));
        if (new Set(guaranteeRanges).size > 1) {
            conflicts.push({
                type: 'guarantee_conflict',
                clauses: guaranteeClauses,
                message: '检测到多处担保范围约定不一致，请确认各担保条款的适用范围是否冲突。'
            });
        }
    }

    // 提取所有包含“利率”“利息”关键词的条款位置
    const rateClauses = extractClausesByKeywords(text, ['利率', '利息', '罚息', '复利']);
    if (rateClauses.length > 1) {
        // 检测利率计算方式冲突
        const rateBases = rateClauses.map(c => extractRateBase(c));
        if (new Set(rateBases).size > 1) {
            conflicts.push({
                type: 'rate_conflict',
                clauses: rateClauses,
                message: '检测到多处利率计算方式不一致，请确认合同中的利率条款是否存在冲突。'
            });
        }
    }

    return conflicts;
}

function extractClausesByKeywords(text, keywords) {
    const regex = new RegExp(`[^。]*?(?:${keywords.join('|')})[^。]*?[。，]`, 'g');
    const matches = text.match(regex) || [];
    return matches.map(m => m.trim());
}

function extractPrioritySubject(clause) {
    // 提取优先主体（简化版）
    const match = clause.match(/([^，,。]*?)(?:的)?(?:优先受偿|优先于|先于)/);
    return match ? match[1].trim() : '未知';
}

function extractPriorityObject(clause) {
    // 提取优先对象（简化版）
    const match = clause.match(/(?:优先受偿|优先于|先于)(?:[^，,。]*?)([^，,。]{2,10}?)(?:的|之|$)/);
    return match ? match[1].trim() : '未知';
}

function extractGuaranteeRange(clause) {
    // 提取担保范围（简化版）
    const match = clause.match(/担保(?:范围|责任|义务)(?:[^，,。]*?)([^，,。]{2,15}?)(?:的|之|$)/);
    return match ? match[1].trim() : '未明确';
}

function extractRateBase(clause) {
    // 提取利率计算基数（简化版）
    const match = clause.match(/利率(?:计算)?(?:基数|方式)(?:[^，,。]*?)([^，,。]{2,10}?)(?:的|之|$)/);
    return match ? match[1].trim() : '未明确';
}
// ===== 银团贷款知识图谱 =====
function syndicatedLoanGraph(text) {
    const governanceIssues = [];

    // 1. 检测代理行授权范围
    const agentAuthorization = extractAgentAuthorization(text);
    if (agentAuthorization.includes('宣布贷款提前到期') || agentAuthorization.includes('加速到期')) {
        // 如果代理行有权宣布提前到期，检查是否有分组分别授权
        const groupAuthorization = extractGroupAuthorization(text);
        if (!groupAuthorization) {
            governanceIssues.push({
                type: 'governance_defect',
                severity: 'high',
                message: '代理行有权宣布贷款提前到期，但未获得各组别的分别授权。建议增加：' +
                    '"代理行行使宣布贷款提前到期的权利，须经受影响组别贷款人分别授权。各组别贷款人可在组别内部自行决定是否行使该权利。"'
            });
        }
    }

    // 2. 检测分组间权利配置
    const groupRights = extractGroupRights(text);
    if (groupRights.length > 1) {
        const rightsSet = new Set(groupRights);
        if (rightsSet.size !== groupRights.length) {
            governanceIssues.push({
                type: 'rights_imbalance',
                severity: 'medium',
                message: '检测到分组间权利配置存在差异，可能引发治理结构缺陷。建议明确各组别权利配置，确保公平性。'
            });
        }
    }

    // 3. 检测代理行职责边界
    const agentDuties = extractAgentDuties(text);
    if (!agentDuties || agentDuties.length < 3) {
        governanceIssues.push({
            type: 'duty_undefined',
            severity: 'high',
            message: '代理行职责边界不清晰，建议补充：' +
                '"代理行的职责包括但不限于：放款审核、本息回收、行使权利、信息传递。代理行执行上述职责时，应依据本合同约定及银团贷款惯例行事。"'
        });
    }

    return governanceIssues;
}

function extractAgentAuthorization(text) {
    const match = text.match(/代理行(?:有权|可以|应|得)(?:[^，,。]*?)([^，,。]{3,30}?)(?:的|之|$)/);
    return match ? match[1].trim() : '';
}

function extractGroupAuthorization(text) {
    const match = text.match(/分组(?:授权|分别授权|独立授权)(?:[^，,。]*?)([^，,。]{3,20}?)(?:的|之|$)/);
    return match ? match[1].trim() : null;
}

function extractGroupRights(text) {
    const matches = text.match(/组别\s*[^，,。]{1,10}?\s*(?:权利|权|义务|责任)/g) || [];
    return matches.map(m => m.trim());
}

function extractAgentDuties(text) {
    const match = text.match(/代理行(?:职责|义务|责任)(?:[^，,。]*?)([^，,。]{3,30}?)(?:的|之|$)/);
    return match ? match[1].trim() : '';
}

// ===== 审查接口（体验版 + 学习容器 + 反馈闭环） =====
app.post('/api/review', async (req, res) => {
    const { text, industry = 'bank', avatar = currentAvatar } = req.body;
    if (!text || text.trim().length === 0) {
        return res.status(400).json({ success: false, error: '合同内容不能为空' });
    }

    console.log(`📋 收到审查请求，行业: ${industry}，分身: ${avatar}`);
    console.log('📌 参数检查:', { industry, avatar });
    console.log('📌 text 长度:', text.length);



    try {
        // 1. 加载规则库
        const rules = loadRules(industry, avatar);
        console.log('📋 加载的规则数量:', rules ? rules.rules?.length : 0);
        console.log('📋 加载的规则名称:', rules ? rules.rules?.map(r => r.name) : '无');
        if (!rules) {
            return res.status(404).json({ success: false, error: '规则库不存在' });
        }

        // 2. 加载肯定池和否定池，影响判断
        const affirmationPool = loadAffirmationPool(avatar, industry);
        const negationPool = loadNegationPool(avatar, industry);
        console.log(`📊 肯定池: ${affirmationPool.length}条，否定池: ${negationPool.length}条`);

        // 3. 执行审查
        const result = reviewContract(text, rules);
        // 4. 语义分析
        const semanticConflicts = semanticAnalyzer(text, result.hits);
        // 5. 银团贷款治理分析
        const governanceIssues = syndicatedLoanGraph(text);

        // 4. 生成报告
        const reportId = 'RPT-' + Date.now();
        const generatedAt = new Date().toLocaleString('zh-CN', { timeZone: 'Asia/Shanghai' });

        let reportContent = '';
        reportContent += '═══════════════════════════════════════════\n';
        reportContent += '  藏器魂 · 合同审查报告（体验版）\n';
        reportContent += `  分身：${avatar}\n`;
        reportContent += `  行业：${rules.name || industry}\n`;
        reportContent += '═══════════════════════════════════════════\n\n';

        reportContent += '【审查结果】\n';
        reportContent += `命中风险条款：${result.hits.length} 条\n`;
        reportContent += `合规评分：${result.score}/100\n`;
        reportContent += `风险等级：${result.level}\n\n`;

        if (result.hits.length === 0) {
            reportContent += '✅ 未检测到风险条款，合同条款合规。\n';
        } else {
            reportContent += '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n';
            reportContent += '  风险条款清单\n';
            reportContent += '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n';
            result.hits.forEach((hit, index) => {
                reportContent += `【风险 ${index + 1}】${hit.name}\n`;
                reportContent += `📌 依据：${hit.why}\n`;
                reportContent += `⚠️ 后果：${hit.consequence}\n`;
                reportContent += `💡 建议：${hit.suggestion}\n\n`;
            });
        }

        reportContent += '═══════════════════════════════════════════\n';
        reportContent += `报告编号：${reportId}\n`;
        reportContent += `生成时间：${generatedAt}\n`;
        reportContent += '数据未联网 · 本地处理\n';
        reportContent += '═══════════════════════════════════════════\n';

        // 5. 保存报告
        const reportPath = path.join(REPORTS_DIR, `审查报告_${reportId}.txt`);
        fs.writeFileSync(reportPath, reportContent, 'utf-8');

        // 6. 记录学习容器会话
        const memory = loadLearningMemory(avatar);
        memory.sessions.push({
            id: 'session_' + Date.now(),
            userMessage: text.slice(0, 200),
            industry: industry,
            hits: result.hits.length,
            score: result.score,
            level: result.level,
            timestamp: new Date().toISOString()
        });
        memory.stats.total_sessions += 1;
        saveLearningMemory(avatar, memory);

        // 7. 返回结果，包含反馈标记
        res.json({
            success: true,
            data: {
                report_id: reportId,
                report_content: reportContent,
                report_path: reportPath,
                hits: result.hits,
                score: result.score,
                level: result.level,
                needs_feedback: true
            }
        });

    } catch (error) {
        console.error('❌ 审查失败:', error.message);
        res.status(500).json({ success: false, error: error.message });
    }
});

// ===== 反馈接口（反问机制 + 修正闭环） =====
app.post('/api/review/feedback', async (req, res) => {
    const { report_id, user_feedback, correction, industry = 'bank', avatar = currentAvatar } = req.body;
    if (!report_id) {
        return res.status(400).json({ success: false, error: '缺少报告ID' });
    }

    console.log(`📋 收到反馈，报告ID: ${report_id}，反馈: ${user_feedback}，分身: ${avatar}`);

    // 记录反馈到学习容器
    const feedback = {
        id: 'fb_' + Date.now(),
        report_id: report_id,
        user_feedback: user_feedback,
        correction: correction || null,
        industry: industry,
        timestamp: new Date().toISOString()
    };

    recordFeedback(avatar, industry, feedback);

    // 更新肯定池或否定池
    const affirmationPool = loadAffirmationPool(avatar, industry);
    const negationPool = loadNegationPool(avatar, industry);

    if (user_feedback === '是') {
        // 肯定池：保留这个判断
        affirmationPool.push({
            id: 'aff_' + Date.now(),
            report_id: report_id,
            industry: industry,
            timestamp: new Date().toISOString()
        });
        if (affirmationPool.length > 500) {
            affirmationPool.splice(0, affirmationPool.length - 500);
        }
        saveAffirmationPool(avatar, industry, affirmationPool);
        console.log(`✅ 肯定池已更新，当前${affirmationPool.length}条`);
    } else if (user_feedback === '不是') {
        // 否定池：标记错误方向
        negationPool.push({
            id: 'neg_' + Date.now(),
            report_id: report_id,
            industry: industry,
            correction: correction || '用户未提供修正指令',
            timestamp: new Date().toISOString()
        });
        if (negationPool.length > 500) {
            negationPool.splice(0, negationPool.length - 500);
        }
        saveNegationPool(avatar, industry, negationPool);
        console.log(`❌ 否定池已更新，当前${negationPool.length}条`);
    }

    // 如果用户说“不是”且有修正指令，触发修正闭环
    if (user_feedback === '不是' && correction) {
        console.log(`🔄 触发修正闭环，新指令: ${correction}`);
        // 返回修正标记，前端重新执行审查
        return res.json({
            success: true,
            data: {
                feedback_recorded: true,
                needs_retry: true,
                correction: correction,
                message: '已记录否定反馈，正在根据修正指令重新执行审查...'
            }
        });
    }

    res.json({
        success: true,
        data: {
            feedback_recorded: true,
            needs_retry: false,
            message: user_feedback === '是' ? '感谢确认，判断已记录。' : '已记录否定反馈。'
        }
    });
});

// ===== 获取报告列表 =====
app.get('/api/reports/list', (req, res) => {
    try {
        const files = fs.readdirSync(REPORTS_DIR).filter(f => f.endsWith('.txt'));
        const reports = files.map(f => {
            const stat = fs.statSync(path.join(REPORTS_DIR, f));
            return { filename: f, size: stat.size, created_at: stat.birthtime };
        });
        res.json({ success: true, reports });
    } catch (e) {
        res.status(500).json({ success: false, error: e.message });
    }
});

// ===== 获取报告内容 =====
app.get('/api/reports/:filename', (req, res) => {
    const { filename } = req.params;
    const filePath = path.join(REPORTS_DIR, filename);
    try {
        if (fs.existsSync(filePath)) {
            const content = fs.readFileSync(filePath, 'utf-8');
            res.json({ success: true, content });
        } else {
            res.status(404).json({ success: false, error: '报告不存在' });
        }
    } catch (e) {
        res.status(500).json({ success: false, error: e.message });
    }
});

// ===== 静态文件服务 =====
app.use(express.static(path.join(__dirname, '..', 'frontend')));
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '..', 'frontend', 'index.html'));
});
// ===== 启动 =====
app.listen(PORT, () => {
    console.log('═══════════════════════════════════════════════');
    console.log('  藏器魂 · 主权审查体验版');
    console.log('  智谱 GLM-4 已启用');
    console.log(`  当前分身: ${currentAvatar}`);
    console.log('  端口: http://127.0.0.1:' + PORT);
    console.log('═══════════════════════════════════════════════');
});