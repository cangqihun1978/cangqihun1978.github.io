#!/bin/bash
# 藏器魂 · 线上体验版一键安装脚本
# 适用系统：Ubuntu 22.04 / 20.04

set -e

echo "═══════════════════════════════════════════════════"
echo "  藏器魂 · 线上体验版安装脚本"
echo "═══════════════════════════════════════════════════"
echo ""

# 1. 检查 Node.js
echo "[1/5] 检查 Node.js 环境..."
if ! command -v node &> /dev/null; then
    echo "⚠️ Node.js 未安装，正在安装..."
    curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
    sudo apt install -y nodejs
fi
echo "✅ Node.js 已就绪（$(node -v)）"
echo ""

# 2. 安装 PM2
echo "[2/5] 安装 PM2 进程管理..."
if ! command -v pm2 &> /dev/null; then
    sudo npm install -g pm2
fi
echo "✅ PM2 已就绪"
echo ""

# 3. 安装依赖
echo "[3/5] 安装后端依赖..."
cd cangqihun_enterprise/backend
npm install --production
echo "✅ 依赖已安装"
echo ""

# 4. 配置环境
echo "[4/5] 配置环境变量..."
if [ -f "../../deploy_config.env" ]; then
    export $(cat ../../deploy_config.env | xargs)
fi
echo "✅ 环境变量已加载"
echo ""

# 5. 启动服务
echo "[5/5] 启动藏器魂服务..."
pm2 start server.js --name cangqihun -- --port=${PORT:-18889}
pm2 save
pm2 startup | tail -1 | bash
echo "✅ 服务已启动（端口: ${PORT:-18889}）"
echo ""

echo "═══════════════════════════════════════════════════"
echo "  ✅ 藏器魂线上体验版部署完成！"
echo "  访问地址: http://$(curl -s ifconfig.me):${PORT:-18889}"
echo "═══════════════════════════════════════════════════"